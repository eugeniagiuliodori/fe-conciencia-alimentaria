import Image from "next/image";

import Link from "next/link";
import fs from "fs";
import path from "path";
import { PublicationsSection } from "@/components/publicaciones/PublicationsSection";
import {MensajeDelDia} from "@/components/mensajediario/ModalDelDia";
import { FormSugerenciaFunciones } from "@/components/formularios/FormSugerenciaFunciones";
import { FormSugerenciaGeneral } from "@/components/formularios/FormSugerenciaGeneral";
import { IdentificationModal } from "@/components/identificacion/IdentificationModal";

export default function Home() {

   const noticiaPath = path.join(
    process.cwd(),
    "public/images/publicaciones/noticiadeldia/noticiadeldia.png"
  );

  const existeNoticia = fs.existsSync(noticiaPath);
  const existeNoticiaLink = true;
  

  const noticiaImageSrc = existeNoticia
    ? "/images/publicaciones/noticiadeldia/noticiadeldia.png"
    : "/images/publicaciones/noticiadeldia/iconnoticia.png";

     const NoticiaLinkSrc = existeNoticia
    ? "https://doi.org/10.1007/s00394-026-04114-4"
    : "/images/publicaciones/noticiadeldia/empty.png";

    const menuSugeridoPath = path.join(
    process.cwd(),
    "public/images/publicaciones/menudeldia/menudeldia.png"
  );

  const existeMenuSugerido = fs.existsSync(menuSugeridoPath);
  const existeMenuSugeridoLink = true;
  

  const menuSugeridoImageSrc = existeMenuSugerido
    ? "/images/publicaciones/menudeldia/menudeldia.png"
    : "/images/publicaciones/menudeldia/iconmenu.png";

     const MenuSugeridoLinkSrc = existeMenuSugerido
    ? "/images/publicaciones/menudeldia/menudeldia.png"
    : "/images/publicaciones/menudeldia/empty.png";


  return (
    <div className="[&_section]:bg-transparent">
      <section
        aria-labelledby="intro-title"
        className="site-container grid items-center gap-10 py-12 sm:py-16 lg:grid-cols-2 lg:gap-16 lg:py-20"
      >
         <div className="flex w-full ">
           
        <div className="flex flex-col max-h-full">
          <p className="mb-5 text-xs font-semibold tracking-[0.16em] text-accent uppercase">
            Un espacio para aprender
          </p>
          <h1
            id="intro-title"
            className="max-w-xl font-display text-2xl leading-[1.12] text-balance sm:text-3xl lg:text-4xl"
          >
            Una mirada curiosa{" "}
            <span className="text-accent">sobre nuestra alimentación.</span>
            <div className="text-accent">y... ¿nos alimentamos únicamente con alimentos?</div>
          </h1>
         <div className="mt-6 max-w-lg rounded-[1rem] bg-[#faf7f1] p-[1rem] text-lg leading-relaxed text-muted shadow-[5px_15px_40px_7px_rgba(50,76,0,1)]">
            <p>
              Bienvenidos a Conciencia Alimentaria.
            </p>

            <p>
              Un lugar para explorar los alimentos, la nutrición, las recetas y la
              fermentación a través de videos y textos.
            </p>
            <p>
              Y también para explorar la alimentación de nuestros cuerpos, más allá de la nutrición.
            </p>
          </div>
          <div className="flex flex-col md:flex-row md:max-w-md lg:max-w-lg justify-between">
          <a href="#publicaciones" className="primary-link mt-8 w-full sm:w-auto">
            Explorar publicaciones <span aria-hidden="true">↓</span>
          </a>
          <MensajeDelDia />
          </div>
           </div>
      <IdentificationModal/>
           
                 
        </div>
        <div className="overflow-hidden rounded-3xl bg-transparent">
          <Image
            src="/images/perfil.png"
            alt=""
            width={800}
            height={620}
            sizes="(min-width: 1184px) 544px, (min-width: 1024px) calc((100vw - 96px) / 2), calc(100vw - 32px)"
            className="h-auto w-full"
            preload
          />
        </div>
      </section>
            <section
        id="recetas"
        aria-labelledby="recetas-title"
        className="site-container border-t border-line py-12 sm:py-16 "
      >
         <div className="flex w-full justify-center ">
            <div className="flex flex-col md:flex-row w-full md:max-w:lg items-center md:items-start justify-between ">
            
            <div className="flex w-60 md:w-full flex-col items-center justify-center rounded-2xl border border-[#D8D0BE] bg-[#EEF0DC]/60 px-2 py-2 text-center shadow-sm">
                <FormSugerenciaFunciones/>
            </div>
            <div
              className="
                flex w-full h-full items-center justify-center
                overflow-hidden 
                border-none
                bg-transparent
                p-3 
                sm:p-4
              "
            >
              <Image
                src="/images/sugerencias/tu-opinion-importante.png"
                alt="Tu opinión es importante. Aporta y ayuda a mejorar."
                width={1383}
                height={1137}
                sizes="(min-width: 768px) 33vw, 100vw"
                className="
                  h-full w-full
                  object-cover
                "
              />
            </div>
            <div className="flex w-60 md:w-full flex-col items-center justify-center rounded-2xl border border-[#D8D0BE] bg-[#EEF0DC]/60 px-2 py-2 text-center shadow-sm">
                <FormSugerenciaGeneral/>
            </div>
            </div>
          </div>
      </section>
      <section    aria-labelledby="noticia-del-dia"
       className="site-container grid items-center gap-10 py-12 sm:py-16 lg:grid-cols-2 lg:gap-16 lg:py-20"
      >
        <div  className="flex flex-col justify-self-center text-center">
          <p className=" mb-5 text-xs font-semibold tracking-[0.16em] text-accent uppercase">
            Una noticia actual relacionada a la alimentación
          </p>
           <div className=" overflow-hidden rounded-3xl bg-transparent">
          <Image
            src={noticiaImageSrc}
            alt=""
            width={800}
            height={620}
            className= {  existeNoticia
            ? "mx-auto h-auto w-[clamp(280px,70vw,520px)] max-w-full"
            : "mx-auto h-auto w-[180px]"
            }   
            preload
          />
        </div>
        <div className="text-center">
          <Link
            href={NoticiaLinkSrc}
            target="_blank"
            rel="noopener noreferrer"
            className="text-link  inline-flex w-fit items-center rounded-sm text-sm font-semibold"
          >        
             { existeNoticiaLink ? "Leer noticia completa" : "Ver" }
            <span className="sr-only">: Noticia del día</span>
          </Link>
        </div>
        </div>
                <div  className="flex flex-col justify-self-center text-center">
          <p className=" mb-5 text-xs font-semibold tracking-[0.16em] text-accent uppercase">
            Menú sugerido diario
          </p>
           <div className=" overflow-hidden rounded-3xl bg-transparent">
          <Image
            src={menuSugeridoImageSrc}
            alt=""
            width={800}
            height={620}
            className= {  existeMenuSugerido
            ? "mx-auto h-auto w-[clamp(280px,70vw,520px)] max-w-full"
            : "mx-auto h-auto w-[180px]"
            }   
            preload
          />
        </div>
        <div className="text-center">
          <Link
            href={MenuSugeridoLinkSrc}
            target="_blank"
            rel="noopener noreferrer"
            className="text-link  inline-flex w-fit items-center rounded-sm text-sm font-semibold"
          >        
             { existeMenuSugeridoLink ? "Ampliar menú" : "Ver" }
            <span className="sr-only">: Menu sugerido</span>
          </Link>
        </div>
        </div>
      </section>
      <section
        id="recetas"
        aria-labelledby="recetas-title"
        className="site-container border-t border-line py-12 sm:py-16 "
      >
         <div className="flex w-full md:h-[4rem] justify-center ">
            <div className="flex flex-col md:flex-row w-full md:max-w:lg items-center md:items-start justify-between ">
            <div className="text-xl py-6 w-full md:w-fit text-center">🌿</div>
            <div className="flex w-50 md:w-30 flex-col items-center justify-center rounded-2xl border border-[#D8D0BE] bg-[#EEF0DC]/60 px-2 py-2 text-center shadow-sm">
              <Link
                href="/recetas"
                rel="noopener noreferrer"
                className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-subaccent px-2 py-2 text-sm font-semibold text-white transition hover:bg-[#354B2B] sm:w-auto"
              >
                <span>Recetas</span>
              </Link>
            </div>
            <div className="text-xl py-6 w-full md:w-fit text-center">🌿</div>
            <div className="flex w-50 md:w-30 flex-col items-center justify-center rounded-2xl border border-[#D8D0BE] bg-[#EEF0DC]/60 px-2 py-2 text-center shadow-sm">
              <a
                href="/pizarra"
                rel="noopener noreferrer"
                className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-subaccent px-2 py-2 text-sm font-semibold text-white transition hover:bg-[#354B2B] sm:w-auto"
              >
                <span> Pizarra </span>
              </a>
            </div>
            <div className="text-xl py-6 w-full md:w-fit text-center">🌿</div>
            <div className="flex w-60 md:w-70 flex-col items-center justify-center rounded-2xl border border-[#D8D0BE] bg-[#EEF0DC]/60 px-2 py-2 text-center shadow-sm">
              <a
                href="/historial_noticias"
                rel="noopener noreferrer"
                className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-subaccent px-2 py-2 text-sm font-semibold text-white transition hover:bg-[#354B2B] sm:w-auto"
              >
                <span>Resúmen mensual ● noticias</span>
              </a>
            </div>
            <div className="text-xl py-6 w-full md:w-fit text-center">🌿</div>
            </div>
          </div>
      </section>
      <PublicationsSection/>

      <section
        id="proyecto"
        aria-labelledby="project-title"
        className="site-container mb-12 grid gap-7 rounded-3xl bg-sand p-6 sm:mb-16 sm:p-10 lg:grid-cols-1 lg:gap-16 lg:p-12"
      >
        
        <div className="space-y-4 text-base leading-relaxed text-muted">
          <h2
            id="project-title"
            className="max-w-sm font-display text-2xl leading-tight sm:text-4xl sm:max-w-4xl"
          >
            Más espacio para cada tema
          </h2>
          <p>
            Conciencia Alimentaria es un proyecto para acercar información, para 
            invitar a un camino propio de hábitos desde lo compartido, investigando,
            cuestionando o descubriendo desde la validación, toda información que
            desde Conciencia Alimentaria se publica.
            Enonctrarás un espacio dedicado a los alimentos, la nutrición, las recetas y la fermentación.
          </p>
          <p>
            Este sitio acompaña al canal de YouTube y ofrece un espacio propio
            para organizar los contenidos, ampliar las explicaciones y reunir las
            fuentes de cada publicación cuando estén disponibles.
          </p>
          <p>
            Esta web será el lugar exclusivo para algunos de los textos y contenidos que se compartan, que no encontrarás en el canal de youtube.
          </p>
          <div className="flex w-full justify-center px-4">
            <div className="flex w-full max-w-md flex-col items-center rounded-2xl border border-[#D8D0BE] bg-[#EEF0DC]/60 px-5 py-4 text-center shadow-sm">
              <p className="text-sm font-medium text-[#6F745E]">
                Podés encontrar contenido desde
              </p>

              <a
                href="https://www.youtube.com/@PropuestaConcienciaAlimentaria"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 inline-flex w-full items-center justify-center gap-2 rounded-full bg-[#49633B] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#354B2B] sm:w-auto"
              >
                <span>▶</span>
                <span>YouTube · Conciencia Alimentaria</span>
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
